//Se ingresan datos de nombres y notas con Prompt
var nombre = prompt("Ingresa el nombre: ");
var apellido = prompt("Ingresa el apellido");
var carrera = prompt("Ingresa la carrera: ");

var ramo1 = prompt("Ingresa el primer ramo ");
var nota1 = prompt("Ingresa nota N°1 de: " + ramo1 + "");
var nota2 = prompt("Ingresa nota N°2 de: " + ramo1 + " ");
var nota3 = prompt("Ingresa nota N°3 de: " + ramo1 + " ");

var ramo2 = prompt("Ingresa el segundo ramo ");
var nota4 = prompt("Ingresa nota N°1 de: " + ramo2 + "");
var nota5 = prompt("Ingresa nota N°2 de: " + ramo2 + " ");
var nota6 = prompt("Ingresa nota N°3 de: " + ramo2 + " ");

var ramo3 = prompt("Ingresa el tercer ramo ");
var nota7 = prompt("Ingresa nota N°1 de: " + ramo3 + "");
var nota8 = prompt("Ingresa nota N°2 de: " + ramo3 + " ");

//Nota mínima de aprobación
var nota_aprob = "4.0";

//Creación de algoritmos para cálculos de promedios y nota necesitada para aprobar
var promedio1 = (Math.round(parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3).toFixed(1);
var promedio2 = (Math.round(parseFloat(nota4) + parseFloat(nota5) + parseFloat(nota6)) / 3).toFixed(1);
var promedio3 = (parseFloat(nota_aprob * 3 - nota7 - nota8));

//Scripts para creación y visualización de tabla dcon datos de alumno en archivo HTML
document.write("<div class='container'>");
document.write("<table class='table'>");
document.write("<thead>");
document.write("<tr>");
document.write("<th scope='col'>Nombre</th>");
document.write("<th scope='col'>Carrera</th>");
document.write("</tr");
document.write("</thead>");
document.write("</table");
document.write("</div>");
document.write("<tr>");
document.write("<td>" + nombre + "</td>");
document.write("<td>" + carrera + "</td>");
document.write("<tr>");
document.write("<tr>");
document.write("<tr>");
document.write("</tbody>");
document.write("</table");
document.write("</div>");

//Scripts para creación y visualización de tabla con datos de ramos y notas de alumno en archivo HTML
document.write("<table class='table'>");
document.write("<thead class='thead-dark'>");
document.write("<tr>");
document.write("<th scope='col'>Ramo</th>");
document.write("<th scope='col'>Nota 1</th>")
document.write("<th scope='col'>Nota 2</th>");
document.write("<th scope='col'>Nota 3</th>");
document.write("<th scope='col'>Promedio</th>");
document.write("</tr>");
document.write("</thead>");
document.write("<tbody>");
document.write("<tr>");
document.write("<th scope='row'>" + ramo1 + "</th>");
document.write("<td>" + nota1 + "</td>");
document.write("<td>" + nota2 + "</td>");
document.write("<td>" + nota3 + "</td>");
document.write("<td>" + promedio1 + "</td>");
document.write("</tr>");
document.write("<th scope='row'>" + ramo2 + "</th>");
document.write("<td>" + nota4 + "</td>");
document.write("<td>" + nota5 + "</td>");
document.write("<td>" + nota6 + "</td>");
document.write("<td>" + promedio2 + "</td>");
document.write("</tr>");
document.write("<th scope='row'>" + ramo3 + "</th>");
document.write("<td>" + nota7 + "</td>");
document.write("<td>" + nota8 + "</td>");
document.write("<td>" + "---" + "</td>");
document.write("<td>" + "---" + "</td>");
document.write("</tr>");
document.write("</tbody>");
document.write("</table>");

//Mensaje final de nota necesaria para aprobar
document.write("<h3>Para alcanzar a aprobar con la nota minima que es 4.0, necesitas conseguir un: " + promedio3 + "</h3>");